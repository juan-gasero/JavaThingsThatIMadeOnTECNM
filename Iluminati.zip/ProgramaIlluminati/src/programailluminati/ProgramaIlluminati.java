
package programailluminati;
import java.util.*;
public class ProgramaIlluminati {

    
    public static void main(String[] args) {
      Scanner LEER= new Scanner(System.in);
      double h, b, a;
      System.out.println("Dame la base y la altura de tu triangulo por favor");
      h=LEER.nextDouble();
      b=LEER.nextDouble();
      a=b*h/2;
      System.out.print("La base de tu triangulo es igual a: "+a);
         
    }
    
}
